package com.aiotico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItoDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItoDemoApplication.class, args);
	}

}
