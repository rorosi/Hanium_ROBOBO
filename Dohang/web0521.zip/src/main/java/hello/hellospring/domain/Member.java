package hello.hellospring.domain;

public class Member {
    private long id; //시스템이 저장하는 아이디
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
